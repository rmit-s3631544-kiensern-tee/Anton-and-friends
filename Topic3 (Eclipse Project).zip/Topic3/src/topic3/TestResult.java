package topic3;

public class TestResult
{
	public static void main(String[] args)
	{
		Result[] results = { new Result(80), new Result(70), new Result(60), new Result(50), new Result(20) };
		// for each result in results
		for(Result result : results)
			System.out.println(result);
	}
}
