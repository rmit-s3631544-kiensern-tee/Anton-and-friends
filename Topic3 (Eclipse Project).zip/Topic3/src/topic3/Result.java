package topic3;

public class Result
{
	private static final int MIN_MARK = 0;
	private static final int MAX_MARK = 100;
	private static final int ERROR_FLAG = -1;

	private int mark;
	private String grade;

	public Result(int mark)
	{
		setMark(mark);
	}

	public int getMark()
	{
		return mark;
	}

	public void setMark(int mark)
	{
		if (mark >= MIN_MARK && mark <= MAX_MARK)
			this.mark = mark;
		else
			this.mark = ERROR_FLAG;
		calculateGrade();
	}

	public String getGrade()
	{
		return grade;
	}

	private void calculateGrade()
	{
		if (mark >= 80)
			grade = "HD";
		else if (mark >= 70)
			grade = "DI";
		else if (mark >= 60)
			grade = "CR";
		else if (mark >= 50)
			grade = "PA";
		else
			grade = "NN";
	}

	public String toString()
	{
		return String.format("Mark: %d, Grade: %s", getMark(), getGrade());
	}
}
