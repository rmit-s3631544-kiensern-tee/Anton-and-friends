package supermarketsystem;

import static org.junit.Assert.*;

import org.junit.Test;

public class ManagerTest {

	@Test
	public void test() {
	
	}

}
