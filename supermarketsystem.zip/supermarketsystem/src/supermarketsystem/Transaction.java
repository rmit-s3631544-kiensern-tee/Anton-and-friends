package supermarketsystem;

import java.util.Scanner;

public class Transaction {

	public void transactionmenu(){
		String shop = "y";
		int choice;
		Scanner scan = new Scanner(System.in);
     	ShoppingCart cart1 = new ShoppingCart();
     	Payment pay = new Payment();
     	do{
	     	System.out.println("Select your choice: ");
			System.out.println("1. Add to Cart (Product Id & Quantity)");
			System.out.println("2. Finish and Pay");
			System.out.println("Choice: ");
			choice = scan.nextInt();
	     		if (choice == 1){
		     		do
		     		{
		     			cart1.menu();
		     			System.out.print ("Continue shopping (y/n)? ");
		     			shop = scan.next();
		     		}while (shop.equals("y"));
	     		}
	     		if (choice == 2){
	     			System.out.print(cart1.toString());
	     			pay.payment(cart1.total());
	     			break;
	     			
	     		}
	     }while(choice == 1 || choice == 2);
	}

	public static void main(String[] args){
	
	}

}

