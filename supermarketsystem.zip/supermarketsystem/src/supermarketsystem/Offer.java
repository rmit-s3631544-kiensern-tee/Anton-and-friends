package supermarketsystem;

public interface Offer {
	public void applyOffer(Product product);
}
