package supermarketsystem;

import static org.junit.Assert.*;

import org.junit.Test;

public class paymentTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
