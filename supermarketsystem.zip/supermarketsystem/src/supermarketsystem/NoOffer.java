package supermarketsystem;

public class NoOffer implements Offer{
	
	@Override
	public void applyOffer(Product product){
		
	}

}
